import React, { Component } from 'react'

export default class Loading extends Component {
    render() {
        return (
            <div>
                <img src='https://wisdomeweb.com/wp-content/uploads/2019/02/All-New-CSS-Loading-Animations.png' style={{alignSelf:'center', width:'100%'}} />
            </div>
        )
    }
}
