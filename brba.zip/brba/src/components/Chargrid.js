import React from 'react'
import CharItem from './CharItem'
import Loading from './Loading'

export default function Chargrid({items, isLoading}) {
    return isLoading ? <Loading/>:<section className='cards'>
        {items.map(item=>(
            <CharItem key={item.char_id} item={item}/>
        ))}
        </section>
    
}
