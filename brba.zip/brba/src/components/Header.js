import React from 'react'

const Header = () => {
    return (
        <header className='center'>
            <img src='https://i.pinimg.com/originals/d3/bb/d0/d3bbd00fc97e601c6dabca395af2e7f6.png' alt='logo'></img>
            
        </header>
    )
}

export default Header
